package com.tensonly.service;

import com.tensonly.dto.UserDto;
import com.tensonly.entity.Role;
import com.tensonly.entity.User;
import com.tensonly.repository.UserRepository;
import com.tensonly.security.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final OtpService otpService;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UserRepository userRepository,
                       OtpService otpService,
                       JwtService jwtService,
                       PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.otpService = otpService;
        this.jwtService = jwtService;
        this.passwordEncoder = passwordEncoder;
    }

    public void requestOtp(String emailOrPhone) {
        otpService.requestOtp(emailOrPhone);
    }

    public boolean verifyOtp(String emailOrPhone, String code) {
        return otpService.verifyOtp(emailOrPhone, code);
    }

    public UserDto.AuthResponse register(UserDto.RegisterRequest request) {
        if (userRepository.findByEmailOrPhone(request.getEmailOrPhone()).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "User already exists with this email or phone");
        }

        User user = new User();
        user.setEmailOrPhone(request.getEmailOrPhone());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        user.setName(request.getName());
        user.setRole(Role.MEMBER);
        user.setApproved(false);
        user.setCity(request.getCity());
        user.setAge(request.getAge());
        user.setGender(request.getGender());
        user.setLoyaltyPoints(0);
        user.setAttendedCount(0);
        user = userRepository.save(user);

        String token = jwtService.generate(user.getId(), user.getEmailOrPhone(), List.of(user.getRole().name()));
        return new UserDto.AuthResponse(token, UserDto.from(user));
    }

    public UserDto.AuthResponse login(UserDto.LoginRequest request) {
        User user = userRepository.findByEmailOrPhone(request.getEmailOrPhone())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
        }

        String token = jwtService.generate(user.getId(), user.getEmailOrPhone(), List.of(user.getRole().name()));
        return new UserDto.AuthResponse(token, UserDto.from(user));
    }

    public UserDto me(String userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
        return UserDto.from(user);
    }
}
