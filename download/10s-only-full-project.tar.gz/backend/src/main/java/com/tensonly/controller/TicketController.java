package com.tensonly.controller;

import com.tensonly.dto.EventDto;
import com.tensonly.dto.TicketDto;
import com.tensonly.repository.TicketRepository;
import com.tensonly.security.SecurityUtil;
import com.tensonly.service.EventService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketRepository ticketRepository;
    private final EventService eventService;
    private final SecurityUtil securityUtil;

    public TicketController(TicketRepository ticketRepository,
                            EventService eventService,
                            SecurityUtil securityUtil) {
        this.ticketRepository = ticketRepository;
        this.eventService = eventService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/mine")
    public ResponseEntity<List<TicketDto>> mine() {
        String userId = securityUtil.currentUserId();
        if (userId == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Not authenticated");
        }
        List<TicketDto> tickets = ticketRepository.findByUserId(userId).stream()
                .map(TicketDto::from)
                .toList();

        // Enrich with event titles
        Map<String, EventDto> eventMap = tickets.stream()
                .map(TicketDto::getEventId)
                .distinct()
                .collect(Collectors.toMap(Function.identity(), id -> {
                    try { return eventService.get(id); } catch (Exception e) { return null; }
                }));
        for (TicketDto t : tickets) {
            EventDto e = eventMap.get(t.getEventId());
            if (e != null) {
                t.setEventTitle(e.getTitle());
            }
        }
        return ResponseEntity.ok(tickets);
    }
}
