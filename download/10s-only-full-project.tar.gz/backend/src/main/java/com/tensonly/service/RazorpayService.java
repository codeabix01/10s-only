package com.tensonly.service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.tensonly.config.AppProperties;
import com.tensonly.dto.PaymentDto;
import com.tensonly.entity.*;
import com.tensonly.repository.*;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;

@Service
public class RazorpayService {

    private static final Logger log = LoggerFactory.getLogger(RazorpayService.class);

    private final AppProperties appProperties;
    private final EventService eventService;
    private final TicketRepository ticketRepository;
    private final PaymentRepository paymentRepository;
    private final LedgerRepository ledgerRepository;
    private final UserRepository userRepository;

    private RazorpayClient cachedClient;

    public RazorpayService(AppProperties appProperties,
                           EventService eventService,
                           TicketRepository ticketRepository,
                           PaymentRepository paymentRepository,
                           LedgerRepository ledgerRepository,
                           UserRepository userRepository) {
        this.appProperties = appProperties;
        this.eventService = eventService;
        this.ticketRepository = ticketRepository;
        this.paymentRepository = paymentRepository;
        this.ledgerRepository = ledgerRepository;
        this.userRepository = userRepository;
    }

    private RazorpayClient getClient() {
        if (cachedClient == null) {
            try {
                cachedClient = new RazorpayClient(
                    appProperties.razorpay().keyId(),
                    appProperties.razorpay().keySecret()
                );
            } catch (RazorpayException e) {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to init Razorpay client: " + e.getMessage());
            }
        }
        return cachedClient;
    }

    public PaymentDto.OrderResponse createOrder(PaymentDto.CreateOrderRequest req, String userId) {
        Event event = eventService.getEntity(req.getEventId());
        long amountPaise = req.getAmount().longValue() * 100;

        try {
            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", amountPaise);
            orderRequest.put("currency", req.getCurrency() != null ? req.getCurrency() : "INR");
            orderRequest.put("receipt", req.getReceipt() != null ? req.getReceipt() : "tkt_" + event.getId());
            orderRequest.put("payment_capture", 1);

            Order order = getClient().orders.create(orderRequest);

            PaymentDto.OrderResponse response = new PaymentDto.OrderResponse();
            response.setId(order.get("id").toString());
            response.setEntity(order.get("entity").toString());
            response.setAmount(((Number) order.get("amount")).longValue());
            response.setAmount_paid(((Number) order.get("amount_paid")).longValue());
            response.setAmount_due(((Number) order.get("amount_due")).longValue());
            response.setCurrency(order.get("currency").toString());
            response.setReceipt(order.get("receipt") != null ? order.get("receipt").toString() : null);
            response.setStatus(order.get("status").toString());
            response.setKeyId(appProperties.razorpay().keyId());
            return response;
        } catch (RazorpayException e) {
            log.error("Razorpay createOrder failed: {}", e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,
                "Failed to create Razorpay order: " + e.getMessage());
        }
    }

    public PaymentDto.PaymentRecord verifyAndCapture(PaymentDto.VerifyRequest req, String userId) {
        String orderId = req.getRazorpayOrderId();
        String paymentId = req.getRazorpayPaymentId();
        String signature = req.getRazorpaySignature();

        // Idempotency
        if (paymentRepository.existsByPaymentId(paymentId)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Payment already verified");
        }

        // Verify signature
        String expectedSignature = generateSignature(orderId + "|" + paymentId,
            appProperties.razorpay().keySecret());
        if (!constantTimeEquals(expectedSignature, signature)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid payment signature");
        }

        Event event = eventService.getEntity(req.getEventId());
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        // Create ticket
        Ticket ticket = new Ticket();
        ticket.setTicketCode(generateTicketCode());
        ticket.setEventId(event.getId());
        ticket.setUserId(userId);
        ticket.setOrderId(orderId);
        ticket.setPaymentId(paymentId);
        ticket.setStatus(TicketStatus.CONFIRMED);
        ticket.setAmountPaid(java.math.BigDecimal.valueOf(req.getAmount()));
        ticket.setCurrency(req.getCurrency());
        ticket.setQrCode("10sonly|" + ticket.getTicketCode() + "|" + event.getId());
        ticket = ticketRepository.save(ticket);

        // Save payment
        Payment payment = new Payment();
        payment.setPaymentId(paymentId);
        payment.setOrderId(orderId);
        payment.setSignature(signature);
        payment.setAmount(java.math.BigDecimal.valueOf(req.getAmount() * 100));  // paise
        payment.setCurrency(req.getCurrency());
        payment.setStatus(PaymentStatus.CAPTURED);
        payment.setEventId(event.getId());
        payment.setUserId(userId);
        payment.setTicketId(ticket.getId());
        payment = paymentRepository.save(payment);

        // Update event stats
        eventService.incrementTicketsSold(event.getId(), 1, java.math.BigDecimal.valueOf(req.getAmount()));

        // Award loyalty points
        user.setLoyaltyPoints(user.getLoyaltyPoints() + 100);
        userRepository.save(user);

        // Ledger entries
        LedgerEntry sale = new LedgerEntry();
        sale.setEventId(event.getId());
        sale.setEventTitle(event.getTitle());
        sale.setType(LedgerType.TICKET_SALE);
        sale.setAmount(java.math.BigDecimal.valueOf(req.getAmount()));
        sale.setCurrency(req.getCurrency());
        sale.setDescription("Ticket " + ticket.getTicketCode() + " sold");
        ledgerRepository.save(sale);

        double feePercent = appProperties.razorpay().platformFeePercent();
        long feeAmount = Math.round(req.getAmount() * feePercent / 100.0);
        LedgerEntry fee = new LedgerEntry();
        fee.setEventId(event.getId());
        fee.setEventTitle(event.getTitle());
        fee.setType(LedgerType.PLATFORM_FEE);
        fee.setAmount(java.math.BigDecimal.valueOf(-feeAmount));
        fee.setCurrency(req.getCurrency());
        fee.setDescription("Platform fee (" + feePercent + "%)");
        ledgerRepository.save(fee);

        // Build response
        PaymentDto.PaymentRecord record = new PaymentDto.PaymentRecord();
        record.setId(payment.getId());
        record.setPaymentId(payment.getPaymentId());
        record.setOrderId(payment.getOrderId());
        record.setSignature(payment.getSignature());
        record.setAmount(req.getAmount());
        record.setCurrency(payment.getCurrency());
        record.setStatus("captured");
        record.setEventId(event.getId());
        record.setUserId(userId);
        record.setTicketId(ticket.getTicketCode());
        record.setVerifiedAt(Instant.now().toString());
        return record;
    }

    private static String generateTicketCode() {
        SecureRandom rng = new SecureRandom();
        return "T-" + (1000 + rng.nextInt(9000));
    }

    private static String generateSignature(String data, String key) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] raw = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : raw) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("HMAC computation failed", e);
        }
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        if (a.length() != b.length()) return false;
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }
}
